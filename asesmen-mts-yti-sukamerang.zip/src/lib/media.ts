import { ApiError, getToken } from "./api";

/**
 * Unggah gambar soal/pilihan jawaban. Mengembalikan URL yang siap dipakai
 * di dalam HTML soal maupun sebagai gambar pilihan jawaban.
 */
export async function uploadImage(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);

  const token = getToken();
  const headers: Record<string, string> = {};
  if (token) headers.Authorization = `Bearer ${token}`;

  let response: Response;
  try {
    response = await fetch("/api/media", { method: "POST", headers, body: form });
  } catch {
    throw new ApiError("Gagal mengunggah gambar. Periksa koneksi internet.", 0);
  }

  const raw = await response.text();
  let data: { url?: string; error?: string } | null = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = null;
  }

  if (!response.ok || !data?.url) {
    throw new ApiError(data?.error ?? "Gagal mengunggah gambar.", response.status);
  }
  return data.url;
}

/** Ambil file dari input lalu unggah; dipakai tombol "Gambar" di opsi jawaban. */
export function pickImage(): Promise<File | null> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/png,image/jpeg,image/webp,image/gif";
    input.onchange = () => resolve(input.files?.[0] ?? null);
    input.oncancel = () => resolve(null);
    input.click();
  });
}
