export type Role = "guru" | "siswa";

export interface User {
  id: number;
  role: Role;
  name: string;
  username: string;
  classId: number | null;
  className: string | null;
}

export interface ClassRow {
  id: number;
  name: string;
  studentCount: number;
}

export interface SubjectRow {
  id: number;
  name: string;
}

export type Choice = "A" | "B" | "C" | "D";

export type QuestionType = "pg" | "pgk" | "bs" | "match" | "essay";

export const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  pg: "Pilihan ganda",
  pgk: "Pilihan ganda kompleks",
  bs: "Benar / salah",
  match: "Menjodohkan",
  essay: "Uraian",
};

export const QUESTION_TYPE_HINTS: Record<QuestionType, string> = {
  pg: "Satu jawaban benar, bobot nilai per soal.",
  pgk: "Lebih dari satu jawaban benar, bobot nilai per pilihan.",
  bs: "Pernyataan dengan kunci Benar atau Salah.",
  match: "Pasangkan kolom kiri dengan kolom kanan, bobot per pasangan.",
  essay: "Jawaban berupa tulisan, dinilai manual oleh guru.",
};

export interface QuestionOption {
  id: string;
  text: string;
  image?: string | null;
  correct: boolean;
  weight?: number;
}

export interface MatchPair {
  id: string;
  left: string;
  right: string;
  weight?: number;
}

export interface Question {
  id: number;
  classId: number;
  subjectId: number;
  type: QuestionType;
  text: string;
  weight: number;
  options: QuestionOption[];
  pairs: MatchPair[];
  answerKey: string;
  maxScore: number;
}

export interface Exam {
  id: number;
  title: string;
  classId: number;
  className: string;
  subjectId: number;
  subjectName: string;
  token: string;
  durationMinutes: number;
  shuffle: boolean;
  isActive: boolean;
  questionCount: number;
  attemptCount: number;
  createdAt: string;
}

export interface StudentExam {
  id: number;
  title: string;
  subjectName: string;
  durationMinutes: number;
  questionCount: number;
  attemptId: number | null;
  status: "belum" | "mengerjakan" | "selesai";
  score: number | null;
  total: number | null;
  startedAt: string | null;
  submittedAt: string | null;
}

export interface ExamQuestionOption {
  id: string;
  text: string;
  image?: string | null;
  weight?: number;
}

export interface ExamQuestion {
  id: number;
  type: QuestionType;
  text: string;
  weight: number;
  options?: ExamQuestionOption[];
  pairs?: { id: string; text: string }[];
  rights?: ExamQuestionOption[];
  maxScore?: number;
}

export interface QuestionAnswer {
  selected: string[];
  matches: Record<string, string>;
  text: string;
}

export interface Violation {
  id?: number;
  type: string;
  detail?: string | null;
  createdAt: string;
}

export interface AttemptInfo {
  id: number;
  examId: number;
  title: string;
  subjectName: string;
  className: string;
  status: "mengerjakan" | "selesai";
  startedAt: string;
  submittedAt: string | null;
  score: number | null;
  total: number | null;
  durationMinutes: number;
  endsAt: string;
}

export interface AttemptPayload {
  attempt: AttemptInfo;
  questions: ExamQuestion[];
  answers: Record<string, QuestionAnswer>;
  violations: Violation[];
}

export interface MonitorStudent {
  studentId: number;
  attemptId: number | null;
  name: string;
  username: string;
  status: "belum" | "mengerjakan" | "selesai";
  answered: number;
  score: number | null;
  total: number | null;
  violations: number;
  startedAt: string | null;
  submittedAt: string | null;
  lastViolationAt: string | null;
}

export interface RecentViolation {
  id: number;
  type: string;
  detail: string | null;
  createdAt: string;
  examId?: number;
  examTitle?: string;
  studentName: string;
  className?: string;
  subjectName?: string;
}

export interface Student {
  id: number;
  name: string;
  username: string;
  classId: number | null;
  className: string | null;
}

export const VIOLATION_LABELS: Record<string, string> = {
  tab_hidden: "Layar ditutup / pindah aplikasi",
  fullscreen_exit: "Keluar dari mode layar penuh",
  window_blur: "Jendela ujian tidak aktif",
  copy_attempt: "Mencoba menyalin soal",
  page_exit: "Mencoba keluar halaman ujian",
  other: "Aktivitas mencurigakan",
};

export function violationLabel(type: string): string {
  return VIOLATION_LABELS[type] ?? "Aktivitas mencurigakan";
}
