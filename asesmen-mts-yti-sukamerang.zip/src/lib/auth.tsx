import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { api, getToken, setToken } from "./api";
import type { Role, User } from "./types";

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  lastAttempt: { id: number; status: "mengerjakan" | "selesai" } | null;
  login: (username: string, password: string, role: Role) => Promise<User>;
  studentLogin: (
    classId: number,
    studentId: number,
    token: string,
  ) => Promise<{ user: User; attemptId: number; status: "mengerjakan" | "selesai" }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [lastAttempt, setLastAttempt] = useState<{ id: number; status: "mengerjakan" | "selesai" } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const boot = async () => {
      if (!getToken()) {
        setLoading(false);
        return;
      }
      try {
        const data = await api<{ user: User }>("/auth/me");
        if (active) setUser(data.user);
      } catch {
        if (active) setUser(null);
      } finally {
        if (active) setLoading(false);
      }
    };
    void boot();
    const onExpired = () => setUser(null);
    window.addEventListener("auth:expired", onExpired);
    return () => {
      active = false;
      window.removeEventListener("auth:expired", onExpired);
    };
  }, []);

  const login = useCallback(async (username: string, password: string, role: Role) => {
    const data = await api<{ token: string; user: User }>("/auth/login", {
      method: "POST",
      body: { username, password, role },
    });
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const studentLogin = useCallback(async (classId: number, studentId: number, token: string) => {
    const data = await api<{
      token: string;
      user: User;
      attempt: { id: number; status: string };
    }>("/auth/student-login", {
      method: "POST",
      body: { classId, studentId, token },
    });
    setToken(data.token);
    setUser(data.user);
    const status = data.attempt.status === "selesai" ? ("selesai" as const) : ("mengerjakan" as const);
    setLastAttempt({ id: data.attempt.id, status });
    return {
      user: data.user,
      attemptId: data.attempt.id,
      status,
    };
  }, []);

  const logout = useCallback(async () => {
    try {
      await api("/auth/logout", { method: "POST" });
    } catch {
      /* ignore */
    }
    setToken(null);
    setUser(null);
    setLastAttempt(null);
  }, []);

  const value = useMemo(
    () => ({ user, loading, lastAttempt, login, studentLogin, logout }),
    [user, loading, lastAttempt, login, studentLogin, logout],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth harus dipakai di dalam AuthProvider");
  return ctx;
}
