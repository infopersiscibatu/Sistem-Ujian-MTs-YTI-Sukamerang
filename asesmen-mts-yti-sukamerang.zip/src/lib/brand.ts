export const APP_NAME = "Asesmen Sumatif Akhir";
export const APP_SHORT = "ASA";
export const SCHOOL_NAME = "MTs YTI Sukamerang";
export const SCHOOL_TAGLINE = "Sukamerang, Kabupaten Garut";
export const SCHOOL_MARK = "MTs";

export const SYSTEM_TITLE = `${APP_NAME} · ${SCHOOL_NAME}`;
