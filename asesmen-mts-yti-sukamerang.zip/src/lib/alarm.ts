let ctx: AudioContext | null = null;

type AudioCtor = typeof AudioContext;

function audioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Ctor: AudioCtor | undefined =
    window.AudioContext ?? (window as unknown as { webkitAudioContext?: AudioCtor }).webkitAudioContext;
  if (!Ctor) return null;
  if (!ctx) ctx = new Ctor();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

/** Dipanggil tepat setelah klik pengguna supaya browser mengizinkan bunyi alarm. */
export function ensureAudio(): void {
  audioContext();
}

/** Sirine alarm untuk siswa yang keluar dari layar ujian. */
export function playSiren(seconds = 6): void {
  const audio = audioContext();
  if (!audio) return;
  const now = audio.currentTime;
  const gain = audio.createGain();
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.4, now + 0.05);
  gain.connect(audio.destination);

  const step = 0.42;
  const cycles = Math.max(1, Math.ceil(seconds / step));
  for (let i = 0; i < cycles; i += 1) {
    const osc = audio.createOscillator();
    osc.type = "square";
    osc.frequency.setValueAtTime(i % 2 === 0 ? 932 : 659, now + i * step);
    osc.connect(gain);
    osc.start(now + i * step);
    osc.stop(now + i * step + step * 0.92);
  }
  gain.gain.setValueAtTime(0.4, now + cycles * step - 0.2);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + cycles * step);
}

/** Bunyi pendek dua nada untuk notifikasi di dashboard guru. */
export function playAlertTone(): void {
  const audio = audioContext();
  if (!audio) return;
  const now = audio.currentTime;
  const gain = audio.createGain();
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.25, now + 0.03);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);
  gain.connect(audio.destination);

  [0, 0.22].forEach((offset, i) => {
    const osc = audio.createOscillator();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(i === 0 ? 1046 : 784, now + offset);
    osc.connect(gain);
    osc.start(now + offset);
    osc.stop(now + offset + 0.28);
  });
}
